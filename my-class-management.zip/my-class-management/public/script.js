document.getElementById('student-form').addEventListener('submit', function(e) {
    e.preventDefault();

    const name = document.getElementById('name').value;
    const dob = document.getElementById('dob').value;
    const grade = document.getElementById('grade').value;

    fetch('/students', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ name, dob, grade })
    })
    .then(response => response.json())
    .then(data => {
        addStudentToList(data);
        document.getElementById('student-form').reset();
    });
});

function addStudentToList(student) {
    const list = document.getElementById('student-list');
    const row = document.createElement('tr');
    row.innerHTML = `
        <td>${student.name}</td>
        <td>${student.dob}</td>
        <td>${student.grade}</td>
        <td>
            <button onclick="deleteStudent(${student.id})">Delete</button>
        </td>
    `;
    list.appendChild(row);
}

function deleteStudent(id) {
    fetch(`/students/${id}`, {
        method: 'DELETE'
    })
    .then(() => {
        document.getElementById('student-list').innerHTML = '';
        fetchStudents();
    });
}

function fetchStudents() {
    fetch('/students')
        .then(response => response.json())
        .then(data => {
            data.forEach(student => {
                addStudentToList(student);
            });
        });
}

document.addEventListener('DOMContentLoaded', fetchStudents);